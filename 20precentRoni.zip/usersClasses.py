class Appraiser:

    def __init__(self, username, name, work_days):
        self.username = username
        self.name = name
        self.work_days = work_days